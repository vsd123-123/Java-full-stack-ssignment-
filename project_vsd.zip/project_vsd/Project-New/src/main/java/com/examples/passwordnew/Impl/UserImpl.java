package com.examples.passwordnew.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.examples.passwordnew.Entity.User;
import com.examples.passwordnew.Repo.UserRepo;
import com.examples.passwordnew.Service.UserService;
import com.examples.passwordnew.UserDto.UserDto;
import com.examples.studentDTO.StudentDTO;
import com.examples.studentEntity.Student;

public class UserImpl  implements  UserService
{
@Autowired
private UserRepo userRepo;

@Autowired 
private PasswordEncoder passwordEncoder;


public String addUser(UserDto userDto) {
	User user =new User(
			userDto.getId(),	
	userDto.getUsername(),
	userDto.getPassword()
		//this.passwordEncoder.encode(userDto.getPassword())
			);
			
userRepo.save(user);
return user.getUsername();
}


}


