package com.examples.passwordnew.Service;

import com.examples.passwordnew.UserDto.UserDto;

public interface UserService {

	static String addUser(UserDto userDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
